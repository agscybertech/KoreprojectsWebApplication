Place html files in this folder to import into HelpConsole. If this folder contains .HTM or .HTML files, an 'import' icon will appear in the contents toolbar (when in edit mode).

Place any associated images in this folder or a subfolder.